/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.sql.Connection;

/**
 *
 * @author Dell
 */
public class LowController {
    static Connection connection()
    {
        try
        {
            
        }
        
    catch(Exception e) 
    {
        System.out.println(e);
    }
    return null;
}
            
    
}

